#!/system/bin/sh

echo 1 > /sys/class/scc_gpio_test/gpio_reload
echo 1 > /sys/class/cx20921/init_signal
