#!/system/bin/sh

log_dir="/sdcard/log"
dumpstate_log_dir="/sdcard/log/dumpstate"
date_now=$(date +"%Y%m%d"_"%H%M%S")

if [ ! -d $log_dir ]; then
    mkdir $log_dir
fi

if [ ! -d $dumpstate_log_dir ]; then
    mkdir -p $dumpstate_log_dir
fi

dumpstate > $dumpstate_log_dir/dumpstate_$date_now.txt
