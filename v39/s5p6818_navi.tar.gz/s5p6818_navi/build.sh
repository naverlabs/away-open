#!/bin/bash

set -e

TOP=`pwd`
RESULT_DIR=${TOP}/result
export TOP RESULT_DIR

BUILD_ALL=true
BUILD_2NDBOOT=false
BUILD_UBOOT=false
BUILD_KERNEL=false
BUILD_NXUPDATE=false
BUILD_MODULE=false
BUILD_ANDROID=false
BUILD_DIST=false
CLEAN_BUILD=false
ROOT_DEVICE_TYPE=sd
#WIFI_DEVICE_NAME=rtl8188   # SDY -- removed
WIFI_DEVICE_NAME=bcmdhd     # SDY -- added
BUILD_TAG=user
#BUILD_TAG=userdebug
#WIFI_DRIVER_PATH="hardware/realtek/wlan/driver/rtl8188EUS_linux_v4.3.0.3_10997.20140327"
#WIFI_DRIVER_PATH="hardware/realtek/wlan/driver/rtl8188eus"     # SDY -- removed
VERBOSE=false
## OTA variables
OTA_INCREMENTAL=false
OTA_PREVIOUS_FILE=
OTA_UPDATE_2NDBOOT=true
OTA_UPDATE_UBOOT=true

CHIP_NAME=
BOARD_NAME=s5p6818_navi
BOARD_PURE_NAME=
BOARD_REV=

ANDROID_VERSION_MAJOR=

DEBUG_TRACE=false

if [ ${BUILD_TAG} == "user" ]; then
BUILD_BUSYBOX=false
else
BUILD_BUSYBOX=true
fi


function check_top()
{
    if [ ! -d .repo ]; then
        echo "You must execute this script at ANDROID TOP Directory"
        exit 1
    fi
}

function usage()
{
    echo "Usage: $0 -b <board-name> [-r <root-device-type> -c -w <wifi-device-name> -t u-boot -t kernel -t module -t android -t dist [-i previous_target.zip  -d u-boot ]]"
    echo -e '\n -b <board-name> : target board name (available boards: "'"$(get_available_board)"'")'
    echo " -r <root-device-type> : your root device type(sd, nand, usb), default sd"
    echo " -c : clean build, default no"
    echo " -w : wifi device name (rtl8188, rtl8712, bcm), default rtl8188"
    echo " -v : if you want to view verbose log message, specify this, default no"
    echo " -x : <board revision> : (1,2), default 2"
    echo " -o : <build mode> : (user,userdebug), default user"
    echo " -t u-boot  : if you want to build u-boot, specify this, default yes"
    echo " -t kernel  : if you want to build kernel, specify this, default yes"
    echo " -t module  : if you want to build driver modules, specify this, default yes"
    echo " -t android : if you want to build android, specify this, default yes"
    echo " -t busybox : if you want to build busybox, specify this, default no on user mode"
    echo " -t none    : if you want to only post process, specify this, default no"
    echo " -t dist    : if you want to build distribute image, specify this, default no"
    echo "    -i previous_target.zip : if you want incremental OTA update, specify this, default no"
    echo "    -d u-boot              : if you don't want to update OTA u-boot, specify this, default no"
}

function parse_args()
{
    TEMP=`getopt -o "b:r:t:i:d:x:o:chvp" -- "$@"`
    eval set -- "$TEMP"

    while true; do
        case "$1" in
            -b ) BOARD_NAME=$2; shift 2 ;;
            -r ) ROOT_DEVICE_TYPE=$2; shift 2 ;;
            -c ) CLEAN_BUILD=true; shift 1 ;;
            -w ) WIFI_DEVICE_NAME=$2; shift 2 ;;
            -x ) BOARD_REV=$2; shift 2 ;;
            -o ) BUILD_TAG=$2; shift 2 ;;
            -t ) case "$2" in
                    u-boot  ) BUILD_ALL=false; BUILD_UBOOT=true ;;
                    kernel  ) BUILD_ALL=false; BUILD_KERNEL=true ;;
                    nxupdate) BUILD_ALL=false; BUILD_NXUPDATE=true ;;
                    module  ) BUILD_ALL=false; BUILD_MODULE=true ;;
                    android ) BUILD_ALL=false; BUILD_ANDROID=true ;;
                    dist    ) BUILD_ALL=false; BUILD_DIST=true ;;
                    busybox ) BUILD_BUSYBOX=true ;;
                    none    ) BUILD_ALL=false ;;
                 esac
                 shift 2 ;;
            -i ) OTA_INCREMENTAL=true; OTA_PREVIOUS_FILE=$2; shift 2 ;;
            -d ) case "$2" in
                    u-boot  ) OTA_UPDATE_UBOOT=false ;;
                 esac
                 shift 2 ;;
            -h ) usage; exit 1 ;;
            -v ) VERBOSE=true; shift 1 ;;
            -p ) DEBUG_TRACE=true; shift 1 ;;
            -- ) break ;;
            *  ) echo "invalid option $1"; usage; exit 1 ;;
        esac
    done
}

function print_args()
{
    if [ ${VERBOSE} == "true" ]; then
        echo "=============================================="
        echo " print args"
        echo "=============================================="
        echo -e "BOARD_NAME:\t\t${BOARD_NAME}"
        echo -e "WIFI_DEVICE_NAME:\t${WIFI_DEVICE_NAME}"
        if [ ${BUILD_ALL} == "true" ]; then
            echo -e "Build:\t\t\tAll"
        else
            if [ ${BUILD_UBOOT} == "true" ]; then
                echo -e "Build:\t\t\tu-boot"
            fi
            if [ ${BUILD_KERNEL} == "true" ]; then
                echo -e "Build:\t\t\tkernel"
            fi
            if [ ${BUILD_MODULE} == "true" ]; then
                echo -e "Build:\t\t\tmodule"
            fi
            if [ ${BUILD_ANDROID} == "true" ]; then
                echo -e "Build:\t\t\tandroid"
            fi
            if [ ${BUILD_DIST} == "true" ]; then
                echo -e "Build:\t\t\tdistribution"
            fi
        fi
        echo -e "ROOT_DEVICE_TYPE:\t${ROOT_DEVICE_TYPE}"
        echo -e "CLEAN_BUILD:\t\t${CLEAN_BUILD}"
    fi
}

function clean_up()
{
    if [ ${CLEAN_BUILD} == "true" ]; then
        echo ""
        echo -e -n "clean up...\t"

        if [ ${BUILD_ALL} == "true" ] || [ ${BUILD_ANDROID} == "true" ]; then  
            rm -rf ${RESULT_DIR}
            make clean
        fi

        echo "End"
    fi
}


function apply_uboot_nand_config()
{
    if [ ${VERBOSE} == "true" ]; then
        echo ""
        echo -e -n "apply nand booting config to u-boot...\t"
    fi

    local dest_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    # backup: include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h.org
    cp ${dest_file} ${dest_file}.org

    local config_logo_load="    #define CONFIG_CMD_LOGO_LOAD    \"ext4load nand 0:1 0x47000000 logo.bmp; drawbmp 0x47000000\""
    sed -i "s/.*#define.*CONFIG_CMD_LOGO_LOAD.*/${config_logo_load}/g" ${dest_file}

    local config_bootcommand="#define CONFIG_BOOTCOMMAND \"ext4load nand 0:1 0x48000000 uImage;ext4load nand 0:1 0x49000000 root.img.gz;bootm 0x48000000\""
    sed -i "s/#define.*CONFIG_BOOTCOMMAND.*/${config_bootcommand}/g" ${dest_file}

    local config_cmd_nand="#define CONFIG_CMD_NAND"
    sed -i "s/\/\/#define.*CONFIG_CMD_NAND/${config_cmd_nand}/g" ${dest_file}
    
    local config_logo_boot_menu_1_load="    #define CONFIG_CMD_LOGO_BOOT_MENU_1    \"ext4load nand 0:1 0x47000000 boot_menu_1.bmp; drawbmp 0x47000000\""
    sed -i "s/.*#define.*CONFIG_CMD_LOGO_BOOT_MENU_1.*/${config_logo_boot_menu_load}/g" ${dest_file}
    
    local config_logo_boot_menu_2_load="    #define CONFIG_CMD_LOGO_BOOT_MENU_2    \"ext4load nand 0:1 0x47000000 boot_menu_2.bmp; drawbmp 0x47000000\""
    sed -i "s/.*#define.*CONFIG_CMD_LOGO_BOOT_MENU_2.*/${config_logo_boot_menu_load}/g" ${dest_file}

    #local config_logo_boot_menu_3_load="    #define CONFIG_CMD_LOGO_BOOT_MENU_3    \"ext4load nand 0:1 0x47000000 boot_menu_3.bmp; drawbmp 0x47000000\"" -- 2017.04.13 joon change boot menu
    #sed -i "s/.*#define.*CONFIG_CMD_LOGO_BOOT_MENU_3.*/${config_logo_boot_menu_load}/g" ${dest_file}

    if [ ${VERBOSE} == "true" ]; then
        echo "End"
    fi
}

function apply_uboot_partition_config()
{
    if [ ${VERBOSE} == "true" ]; then
        echo ""
        echo -e -n "apply sd/usb partition info at android BoardConfig.mk to u-boot...\t"
    fi

    local dest_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    local src_file=${TOP}/device/nexell/${BOARD_NAME}/BoardConfig.mk
    cp ${dest_file} ${dest_file}.org

    local system_partition_size=`awk '/BOARD_SYSTEMIMAGE_PARTITION_SIZE/{print $3}' ${src_file}`
    local cache_partition_size=`awk '/BOARD_CACHEIMAGE_PARTITION_SIZE/{print $3}' ${src_file}`

    echo "system_partition_size: ${system_partition_size}, cache_partition_size: ${cache_partition_size}"

    sed -i "s/#define CFG_SYSTEM_PART_SIZE.*/#define CFG_SYSTEM_PART_SIZE    (${system_partition_size})/g" ${dest_file}
    sed -i "s/#define CFG_CACHE_PART_SIZE.*/#define CFG_CACHE_PART_SIZE     (${cache_partition_size})/g" ${dest_file}

    if [ ${VERBOSE} == "true" ]; then
        echo "End"
    fi
}

function enable_uboot_sd_root()
{
    local src_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    sed -i 's/^\/\/#define[[:space:]]CONFIG_CMD_MMC/#define CONFIG_CMD_MMC/g' ${src_file}
    sed -i 's/^\/\/#define[[:space:]]CONFIG_LOGO_DEVICE_MMC/#define CONFIG_LOGO_DEVICE_MMC/g' ${src_file}
    local root_device_num=$(get_sd_device_number ${TOP}/device/nexell/${BOARD_NAME}/fstab.${BOARD_NAME})
    sed -i 's/^#define[[:space:]]CONFIG_BOOTCOMMAND.*/#define CONFIG_BOOTCOMMAND \"ext4load mmc '"${root_device_num}"':1 0x48000000 uImage;ext4load mmc '"${root_device_num}"':1 0x49000000 root.img.gz;bootm 0x48000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_WALLPAPERS.*/    #define CONFIG_CMD_LOGO_WALLPAPERS \"ext4load mmc '"${root_device_num}"':1 0x47000000 logo.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_BATTERY.*/    #define CONFIG_CMD_LOGO_BATTERY \"ext4load mmc '"${root_device_num}"':1 0x47000000 battery.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_UPDATE.*/    #define CONFIG_CMD_LOGO_UPDATE \"ext4load mmc '"${root_device_num}"':1 0x47000000 update.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]](CONFIG_CMD_LOGO_BOOT_MENU_1.*/    #define (CONFIG_CMD_LOGO_BOOT_MENU_1 \"ext4load mmc '"${root_device_num}"':1 0x47000000 boot_menu_1.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]](CONFIG_CMD_LOGO_BOOT_MENU_2.*/    #define (CONFIG_CMD_LOGO_BOOT_MENU_2 \"ext4load mmc '"${root_device_num}"':1 0x47000000 boot_menu_2.bmp; drawbmp 0x47000000\"/g' ${src_file}
    #sed -i 's/.*#define[[:space:]](CONFIG_CMD_LOGO_BOOT_MENU_3.*/    #define (CONFIG_CMD_LOGO_BOOT_MENU_3 \"ext4load mmc '"${root_device_num}"':1 0x47000000 boot_menu_3.bmp; drawbmp 0x47000000\"/g' ${src_file}  -- 2017.04.13 joon change boot menu
}

function disable_uboot_sd_root()
{
    local src_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    echo "src_file: ${src_file}"
    #nand:release)
    #sed -i 's/^#define[[:space:]]CONFIG_CMD_MMC/\/\/#define CONFIG_CMD_MMC/g' ${src_file}
    sed -i 's/^#define[[:space:]]CONFIG_LOGO_DEVICE_MMC/\/\/#define CONFIG_LOGO_DEVICE_MMC/g' ${src_file}
}

function enable_uboot_nand_root()
{
    local src_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    sed -i 's/^\/\/#define[[:space:]]CONFIG_CMD_NAND/#define CONFIG_CMD_NAND/g' ${src_file}
    sed -i 's/^\/\/#define[[:space:]]CONFIG_NAND_FTL/#define CONFIG_NAND_FTL/g' ${src_file}
    sed -i 's/^\/\/#define[[:space:]]CONFIG_LOGO_DEVICE_NAND/#define CONFIG_LOGO_DEVICE_NAND/g' ${src_file}
    sed -i 's/^#define[[:space:]]CONFIG_BOOTCOMMAND.*/#define CONFIG_BOOTCOMMAND \"ext4load nand 0:1 0x48000000 uImage;ext4load nand 0:1 0x49000000 root.img.gz;bootm 0x48000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_WALLPAPERS.*/    #define CONFIG_CMD_LOGO_WALLPAPERS \"ext4load nand 0:1 0x47000000 logo.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_BATTERY.*/    #define CONFIG_CMD_LOGO_BATTERY \"ext4load nand 0:1 0x47000000 battery.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_UPDATE.*/    #define CONFIG_CMD_LOGO_UPDATE \"ext4load nand 0:1 0x47000000 update.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_BOOT_MENU_1.*/    #define CONFIG_CMD_LOGO_BOOT_MENU_1 \"ext4load nand 0:1 0x47000000 boot_menu_1.bmp; drawbmp 0x47000000\"/g' ${src_file}
    sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_BOOT_MENU_2.*/    #define CONFIG_CMD_LOGO_BOOT_MENU_2 \"ext4load nand 0:1 0x47000000 boot_menu_2.bmp; drawbmp 0x47000000\"/g' ${src_file}
    #sed -i 's/.*#define[[:space:]]CONFIG_CMD_LOGO_BOOT_MENU_3.*/    #define CONFIG_CMD_LOGO_BOOT_MENU_3 \"ext4load nand 0:1 0x47000000 boot_menu_3.bmp; drawbmp 0x47000000\"/g' ${src_file} -- 2017.04.13 joon change boot menu
}

function disable_uboot_nand_root()
{
    local src_file=${TOP}/u-boot/include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
    sed -i 's/^#define[[:space:]]CONFIG_CMD_NAND/\/\/#define CONFIG_CMD_NAND/g' ${src_file}
    sed -i 's/^#define[[:space:]]CONFIG_NAND_FTL/\/\/#define CONFIG_NAND_FTL/g' ${src_file}
    sed -i 's/^#define[[:space:]]CONFIG_LOGO_DEVICE_NAND/\/\/#define CONFIG_LOGO_DEVICE_NAND/g' ${src_file}
}

function apply_uboot_sd_root()
{
    echo "====> apply sd root"
    disable_uboot_nand_root
    enable_uboot_sd_root
}

function apply_uboot_nand_root()
{
    echo "====> apply nand root"
    disable_uboot_sd_root
    enable_uboot_nand_root
}

function build_uboot()
{
    if [ ${BUILD_ALL} == "true" ] || [ ${BUILD_UBOOT} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build u-boot"
        echo "=============================================="

        if [ ! -e ${TOP}/u-boot ]; then
            cd ${TOP}
            ln -s linux/bootloader/u-boot-2014.07 u-boot
        fi

        cd ${TOP}/u-boot
        make distclean

        echo "ROOT_DEVICE_TYPE is ${ROOT_DEVICE_TYPE}"
        #case ${ROOT_DEVICE_TYPE} in
            #sd) apply_uboot_sd_root ;;
            #nand) apply_uboot_nand_root ;;
        #esac

        make ${CHIP_NAME}_${BOARD_PURE_NAME}_config
        make -j8
        check_result "build-uboot"
        if [ -f include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h.org ]; then
            mv include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h.org include/configs/${CHIP_NAME}_${BOARD_PURE_NAME}.h
        fi
        cd ${TOP}

        echo "---------- End of build u-boot"
    fi
}

function apply_kernel_nand_config()
{
    local src_file=${TOP}/kernel/arch/arm/configs/${CHIP_NAME}_${BOARD_PURE_NAME}_android_defconfig
    local dst_config=${CHIP_NAME}_${BOARD_PURE_NAME}_android_defconfig.nandboot
    local dst_file=${src_file}.nandboot
    cp ${src_file} ${dst_file}

	# FTL
	sed -i 's/.*CONFIG_NXP_FTL .*/CONFIG_NXP_FTL=y\nCONFIG_NAND_FTL=y/g' ${dst_file}
    
    echo ${dst_config}
}

function build_nxupdate()
{
    if [ ${BUILD_NXUPDATE} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build nxupdate kernel"
        echo "=============================================="

        if [ ! -e ${TOP}/kernel ]; then
            cd ${TOP}
            ln -s linux/kernel/kernel-3.4.39 kernel
        fi

        cd ${TOP}/kernel

        local kernel_config=${CHIP_NAME}_${BOARD_PURE_NAME}_update_defconfig

        if [ ${ROOT_DEVICE_TYPE} == "nand" ]; then
            kernel_config=$(apply_kernel_nand_config)
            echo "nand kernel config: ${kernel_config}"
        fi

        make distclean
        cp arch/arm/configs/${kernel_config} .config
        yes "" | make ARCH=arm oldconfig
        make ARCH=arm uImage_update -j8

        if [ ${ROOT_DEVICE_TYPE} == "nand" ]; then
            rm -f ${TOP}/arch/arm/configs/${kernel_config}
        fi

        check_result "build-nxupdate kernel"

        echo "---------- End of build nxupdate kernel"
    fi
}

function build_kernel()
{
    if [ ${BUILD_ALL} == "true" ] || [ ${BUILD_KERNEL} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build kernel"
        echo "=============================================="

        if [ ! -e ${TOP}/kernel ]; then
            cd ${TOP}
            ln -s linux/kernel/kernel-3.4.39 kernel
        fi

        cd ${TOP}/kernel

        local kernel_config=
        if [ ${ANDROID_VERSION_MAJOR} == "4" ]; then
            kernel_config=${CHIP_NAME}_${BOARD_PURE_NAME}_android_defconfig
        elif [ ${ANDROID_VERSION_MAJOR} == "5" ]; then
			local append=
			if [ ${DEBUG_TRACE} == "true" ]; then
				append="debug_"
			fi

            if [ ${BOARD_REV} == "1" ]; then
             	kernel_config=${CHIP_NAME}_${BOARD_PURE_NAME}_rev1_${append}android_lollipop_defconfig
            else
            	kernel_config=${CHIP_NAME}_${BOARD_PURE_NAME}_${append}android_lollipop_defconfig
            fi
        else
            echo "ANDROID_VERSION_MAJOR is abnormal!!! ==> ${ANDROID_VERSION_MAJOR}"
            exit 1
        fi

        if [ ${ROOT_DEVICE_TYPE} == "nand" ]; then
            kernel_config=$(apply_kernel_nand_config)
            echo "nand kernel config: ${kernel_config}"
        fi

        make distclean     # SDY
        cp arch/arm/configs/${kernel_config} .config   # SDY
        yes "" | make ARCH=arm oldconfig   # SDY
        make ARCH=arm uImage -j8

#       make ARCH=arm modules
#       sudo make ARCH=arm CROSS_COMPILE=/home/sdy1350/WORK/navi/trunk/sw/android/lollipop-5.1.1_r6-avn-release_2nd/prebuilts/gcc/linux-x86/arm/arm-eabi-4.8/bin/arm-eabi- modules_install

        if [ ${ROOT_DEVICE_TYPE} == "nand" ]; then
            rm -f ${TOP}/arch/arm/configs/${kernel_config}
        fi

        check_result "build-kernel"

        echo "---------- End of build kernel"
    fi
}

function build_module()
{
    if [ ${BUILD_ALL} == "true" ] || [ ${BUILD_MODULE} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build modules"
        echo "=============================================="

        local out_dir=${TOP}/out/target/product/${BOARD}
        mkdir -p ${out_dir}/system/lib/modules

        if [ ${VERBOSE} == "true" ]; then
            echo -n -e "build vr driver..."
        fi
        #cd ${TOP}/hardware/samsung_slsi/slsiap/prebuilt/modules/vr
        #./build.sh
        #if [ ${VERBOSE} == "true" ]; then
            #echo "End"
        #fi

        #if [ ${VERBOSE} == "true" ]; then
            #echo -n -e "build coda driver..."
        #fi
        #cd ${TOP}/linux/platform/${CHIP_NAME}/modules/coda960
        #./build.sh
        #if [ ${VERBOSE} == "true" ]; then
            #echo "End"
        #fi

        #if [ ${VERBOSE} == "true" ]; then
            #echo -n -e "build zeroboot driver..."
        #fi
        #cd ${TOP}/linux/platform/${CHIP_NAME}/modules/zeroboot
        #./build.sh
        #if [ ${VERBOSE} == "true" ]; then
            #echo "End"
        #fi

        if [ ${VERBOSE} == "true" ]; then
            echo -n -e "build wifi driver..."
        fi

# SDY --- removed
#cd ${TOP}/${WIFI_DRIVER_PATH}
#./build.sh
#if [ ${VERBOSE} == "true" ]; then
#    echo "End"
#fi


        cd ${TOP}

        if [ ${VERBOSE} == "true" ]; then
            echo "End"
        fi

        echo "---------- End of build modules"
    fi
}

function make_android_root()
{
    local out_dir=${TOP}/out/target/product/${BOARD_NAME}
    cd ${out_dir}/root
    sed -i -e '/mount\ yaffs2/ d' -e '/on\ fs/ d' -e '/mount\ mtd/ d' -e '/Mount\ \// d' init.rc

    awk '/console\ \/system/{print; getline; print; getline; print; getline; print; getline; print "    user root"; getline}1' init.rc > /tmp/init.rc
    mv /tmp/init.rc init.rc

    # handle nand boot
    if [ ${ROOT_DEVICE_TYPE} == "nand" ]; then
		sed -i 's/.*\/dev.*\/p2.*/\/dev\/block\/mio2              \/system             ext4      rw                                                            wait/g' fstab.${BOARD_NAME}
		sed -i 's/.*\/dev.*\/p3.*/\/dev\/block\/mio3              \/cache              ext4      noatime,nosuid,nodev,nomblk_io_submit,discard,errors=panic    wait,check/g' fstab.${BOARD_NAME}
		sed -i 's/.*\/dev.*\/p7.*/\/dev\/block\/mio7              \/data               ext4      noatime,nosuid,nodev,nomblk_io_submit,discard,errors=panic    wait,check/g' fstab.${BOARD_NAME}
    fi

    # arrange permission
    chmod 644 *.prop
    chmod 644 *.${BOARD_NAME}
    chmod 644 *.rc

    cd ..
    rm -f root.img.gz
    cd ${TOP}
}

function apply_android_overlay()
{
    cd ${TOP}
    local overlay_dir=${TOP}/hardware/samsung_slsi/slsiap/overlay-apps
    local overlay_list_file=${overlay_dir}/files.txt
    local token1=""
    while read line; do
        token1=$(echo ${line} | awk '{print $1}')
        if [ ${token1} == "replace" ]; then
            local src_file=$(echo ${line} | awk '{print $2}')
            local replace_file=$(echo ${line} | awk '{print $3}')
            cp ${overlay_dir}/${src_file} ${RESULT_DIR}/${replace_file}
        elif [ ${token1} == "remove" ]; then
            local remove_file=$(echo ${line} | awk '{print $2}')
            rm -f ${RESULT_DIR}/${remove_file}
        fi
    done < ${overlay_list_file}
}

function remove_android_banned_files()
{
    rm -f ${RESULT_DIR}/system/xbin/su
}

function refine_android_system()
{
    local out_dir=${TOP}/out/target/product/${BOARD_NAME}
    cd ${out_dir}/system
    chmod 644 *.prop
    #chmod 644 lib/modules/*
    cd ${TOP}
}

function patch_android()
{
    cd ${TOP}
    local patch_dir=${TOP}/hardware/samsung_slsi/slsiap/patch
    local patch_list_file=${patch_dir}/files.txt
    local src_file=""
    local dst_dir=""
    while read line; do
        src_file=$(echo ${line} | awk '{print $1}')
        dst_dir=$(echo ${line} | awk '{print $2}')
        echo "copy ${patch_dir}/${src_file}  =====> ${TOP}/${dst_dir}"
        cp ${patch_dir}/${src_file} ${TOP}/${dst_dir}
    done < ${patch_list_file}
    cd ${TOP}
}

function restore_patch()
{
    cd ${TOP}
    if [ -d ${TOP}/.repo ]; then
        local patch_dir=${TOP}/hardware/samsung_slsi/slsiap/patch
        local patch_list_file=${patch_dir}/files.txt
        local src_file=""
        local dst_dir=""
        while read line; do
            src_file=$(echo ${line} | awk '{print $1}')
            dst_dir=$(echo ${line} | awk '{print $2}')
            echo "restore ${TOP}/${dst_dir}/${src_file}"
            cd ${TOP}/${dst_dir}
            git status | grep -q Untracked || git checkout ${src_file}
        done < ${patch_list_file}
        cd ${TOP}
    fi
}

function apply_kernel_headers()
{
    # make install kernel header
    #local tmp_install_header=/tmp/install_headers
    #mkdir -p ${tmp_install_header}
    #cd ${TOP}/kernel
    #make headers_install ARCH=arm INSTALL_HDR_PATH=${tmp_install_header}
    #cd ${TOP}
    #local header_dir=${tmp_install_header}/include

    #local asm_arm_header_dir=${tmp_install_header}/include/asm
    local android_kernel_header=${TOP}/external/kernel-headers/original
    #cp -a ${asm_arm_header_dir}/* ${android_kernel_header}/asm-arm
    #cp -a ${header_dir}/asm-generic/* ${android_kernel_header}/asm-generic
    #cp -a ${header_dir}/linux/* ${android_kernel_header}/linux
    ##cp -a ${header_dir}/media/* ${android_kernel_header}/media
    #cp -a ${header_dir}/mtd/* ${android_kernel_header}/mtd
    #cp -a ${header_dir}/sound/* ${android_kernel_header}/sound
    ##cp -a ${header_dir}/uapi/* ${android_kernel_header}/uapi
    #cp -a ${header_dir}/video/* ${android_kernel_header}/video
    cp kernel/include/linux/ion.h ${android_kernel_header}/linux
    ${TOP}/bionic/libc/kernel/tools/update_all.py
}

function apply_kernel_ion_header()
{
    local kernel_ion_header=kernel/include/linux/ion.h
    local bionic_ion_header=bionic/libc/kernel/common/linux/ion.h
    local libion=system/core/libion/ion.c
    cp ${kernel_ion_header} ${bionic_ion_header}
    sed -i 's/heap_mask/heap_id_mask/g' ${libion}
}

function build_cts()
{
    make -j8 PRODUCT-aosp_${BOARD_NAME}-${BUILD_TAG} cts
}

function sign_system_private_app()
{
    java -jar out/host/linux-x86/framework/signapk.jar vendor/nexell/security/${BOARD_NAME}/platform.x509.pem vendor/nexell/security/${BOARD_NAME}/platform.pk8 out/target/product/${BOARD_NAME}/system/app/OTAUpdateCenter.apk /tmp/OTAUpdateCenter.apk
    mv /tmp/OTAUpdateCenter.apk out/target/product/${BOARD_NAME}/system/app/
    sync
}

function generate_key()
{
    echo "key generation for ${BOARD_NAME}"
    [ ! -e  ${TOP}/vendor/nexell/security/${BOARD_NAME}/media.pk8 ] && ${TOP}/device/nexell/tools/mkkey.sh media ${BOARD_NAME}
    [ ! -e  ${TOP}/vendor/nexell/security/${BOARD_NAME}/platform.pk8 ] && $(${TOP}/device/nexell/tools/mkkey.sh platform ${BOARD_NAME})
    [ ! -e  ${TOP}/vendor/nexell/security/${BOARD_NAME}/release.pk8 ] && ${TOP}/device/nexell/tools/mkkey.sh release ${BOARD_NAME}
    [ ! -e  ${TOP}/vendor/nexell/security/${BOARD_NAME}/shared.pk8 ] && ${TOP}/device/nexell/tools/mkkey.sh shared ${BOARD_NAME}
    [ ! -e  ${TOP}/vendor/nexell/security/${BOARD_NAME}/testkey.pk8 ] && ${TOP}/device/nexell/tools/mkkey.sh testkey ${BOARD_NAME}
    echo "End of generate_key"
}

function build_android()
{
    if [ ${BUILD_ALL} == "true" ] || [ ${BUILD_ANDROID} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build android"
        echo "=============================================="

        #patch_android

        if [ ${ANDROID_VERSION_MAJOR} == "4" ]; then
            apply_kernel_ion_header
        fi

        make -j8 PRODUCT-aosp_${BOARD_NAME}-${BUILD_TAG}
        check_result "build-android"

        make_android_root
        refine_android_system

        #sign_system_private_app

        #build_cts

        #restore_patch

        echo "---------- End of build android"
    fi
}

function build_dist()
{
    if [ ${BUILD_DIST} == "true" ]; then
        echo ""
        echo "=============================================="
        echo "build dist"
        echo "=============================================="

        #patch_android
        
        make -j8 PRODUCT-aosp_${BOARD_NAME}-${BUILD_TAG} dist

        cp ${TOP}/out/dist/aosp_${BOARD_NAME}-target_files-eng.$(whoami).zip ${RESULT_DIR}/${BOARD_NAME}-target_files.zip

#cp ${TOP}/out/dist/aosp_${BOARD_NAME}-target_files-eng..zip ${RESULT_DIR}/${BOARD_NAME}-target_files.zip
        
		local tmpdir=${RESULT_DIR}/tmp
    #rm -rf ${tmpdir}
        rm -rf ${tmpdir}/*
        rm -f ${RESULT_DIR}/target.zip
    
        if [ ! -d ${tmpdir} ]; then
            mkdir -p ${tmpdir}
        fi

    #mkdir -p ${tmpdir}
        unzip -o -q ${RESULT_DIR}/${BOARD_NAME}-target_files.zip -d ${tmpdir}
        mkdir -p ${tmpdir}/BOOTABLE_IMAGES/
        local otaver=$(cat device/nexell/${BOARD_NAME}/otaver)
        otaver=$((otaver+1))
        sed -i "s/setprop otaupdater.otaver.*/setprop otaupdater.otaver ${otaver}/g" ${RESULT_DIR}/root/init.${BOARD_NAME}.rc
        local release_date=$(date +%Y%m%d-%H%M)
        sed -i "s/setprop otaupdater.otatime.*/setprop otaupdater.otatime ${release_date}/g" ${RESULT_DIR}/root/init.${BOARD_NAME}.rc
        ${TOP}/device/nexell/tools/mkinitramfs.sh ${RESULT_DIR}/root ${RESULT_DIR}
        cp ${RESULT_DIR}/root.img.gz ${RESULT_DIR}/boot
        cp ${RESULT_DIR}/root.img.gz ${TOP}/out/target/product/${BOARD_NAME}/ramdisk.img
		#nand
        #if [ ${ROOT_DEVICE_TYPE} != "nand" ]; then
            make_ext4 ${BOARD_NAME} boot
        #fi
        cp ${RESULT_DIR}/boot.img ${tmpdir}/BOOTABLE_IMAGES
#cp out/target/product/${BOARD_NAME}/recovery.img ${tmpdir}/BOOTABLE_IMAGES     # SDY -- removed
        cp ${RESULT_DIR}/recovery.img ${tmpdir}/BOOTABLE_IMAGES     # SDY -- added

#cp ${TOP}/device/nexell/s5p6818_navi/updater-recovery-script ${tmpdir}/META-INF/com/google/android/     # SDY -- added

        OTA_UPDATE_UBOOT=true
        OTA_UPDATE_2NDBOOT=true

        if [ ${OTA_UPDATE_UBOOT} == "true" ] || [ ${OTA_UPDATE_2NDBOOT} == "true" ]; then
            mkdir -p ${tmpdir}/RADIO
            if [ ${OTA_UPDATE_UBOOT} == "true" ]; then
                if [ ${ROOT_DEVICE_TYPE} == "sd" ]; then
                    local port=$(get_sd_device_number ${TOP}/device/nexell/${BOARD_NAME}/fstab.${BOARD_NAME})
                    ${TOP}/linux/platform/common/tools/sd/sd_bootgen/sd_ubootgen -i ${RESULT_DIR}/u-boot.bin -o ${RESULT_DIR}/u-boot.bin_sd -l 42c00000 -p ${port}
                    cp ${RESULT_DIR}/u-boot.bin_sd ${tmpdir}/RADIO/bootloader
                else
                    cp ${RESULT_DIR}/u-boot.bin ${tmpdir}/RADIO/bootloader
                fi
            fi
        fi
        cd ${tmpdir}
        zip --symlinks -r -q ../target *
        cd ${TOP}
        if [ ${ANDROID_VERSION_MAJOR} == "4" ]; then
            cp build/tools/releasetools/common.py /tmp/
            cp device/nexell/tools/common.py build/tools/releasetools/
        fi
        local ota_name="ota-${BOARD_NAME}-${release_date}.zip"
        local i_option=
        if [ ${OTA_INCREMENTAL} == "true" ]; then
            if [ -f ${OTA_PREVIOUS_FILE} ]; then
                local src_tmpdir=${RESULT_DIR}/src_tmp
                rm -rf ${src_tmpdir}
                rm -f ${RESULT_DIR}/src_target.zip
                mkdir -p ${src_tmpdir}
                unzip -o -q ${OTA_PREVIOUS_FILE} -d ${src_tmpdir}
                cp ${RESULT_DIR}/boot.img ${src_tmpdir}/BOOTABLE_IMAGES
                cp ${RESULT_DIR}/recovery.img ${src_tmpdir}/BOOTABLE_IMAGES     # SDY -- added
                cd ${src_tmpdir}
                zip --symlinks -r -q ../src_target *
                cd ${TOP}
                i_option="-i ${RESULT_DIR}/src_target.zip"
            fi
        fi
        echo "i_option ====> ${i_option}"
        if [ ${ANDROID_VERSION_MAJOR} == "4" ]; then
            build/tools/releasetools/ota_from_target_files -v -p out/host/linux-x86 -k vendor/naverlabs/security/releasekey ${i_option} ${RESULT_DIR}/target.zip ${RESULT_DIR}/${ota_name}
            mv /tmp/common.py build/tools/releasetools/
        else
            build/tools/releasetools/ota_from_target_files -v -p out/host/linux-x86 -k vendor/naverlabs/security/releasekey ${i_option} ${RESULT_DIR}/target.zip ${RESULT_DIR}/${ota_name}
        fi

        #restore_patch

        local ota_desc=${RESULT_DIR}/OTA_DESC
        if [ ${ANDROID_VERSION_MAJOR} == "4" ]; then
            echo "Rom Name: aosp_${BOARD_NAME}-${BUILD_TAG} 4.4.2 KOT49H ${release_date}" > ${ota_desc}
            echo "Rom ID: samsung_slsiap_${BOARD_NAME}_kk" >> ${ota_desc}
        else
            echo "Rom Name: aosp_${BOARD_NAME}-${BUILD_TAG} 5.1.1 LMY48G ${release_date}" > ${ota_desc}
            echo "Rom ID: samsung_slsiap_${BOARD_NAME}_lp" >> ${ota_desc}
        fi
        echo -e ${otaver} | awk '{print "Rom Version: " $1}' >> ${ota_desc}
        echo "Rom Date: ${release_date}" >> ${ota_desc}
        echo "Download URL: http://git.nexell.co.kr/_builds/${ota_name}" >> ${ota_desc}
        md5sum ${RESULT_DIR}/${ota_name} | awk '{print "MD5 Checksum: " $1}' >> ${ota_desc}
        echo "Device(code)name: ${BOARD_NAME}" >> ${ota_desc}

        echo -e ${otaver} > device/nexell/${BOARD_NAME}/otaver

        echo "---------- End of build dist"
    fi
}

function make_boot()
{
    vmsg "start make_boot"
    local out_dir="${TOP}/out/target/product/${BOARD_NAME}"

    mkdir -p ${RESULT_DIR}/boot

    cp ${TOP}/kernel/arch/arm/boot/Image ${RESULT_DIR}/boot
    cp ${TOP}/kernel/arch/arm/boot/uImage ${RESULT_DIR}/boot
	if [ ${BUILD_NXUPDATE} == "true" ]; then
    cp ${TOP}/kernel/arch/arm/boot/uImage_update ${RESULT_DIR}/boot
    cp ${TOP}/device/nexell/${BOARD_NAME}/ramdisk_update.gz ${RESULT_DIR}/boot
	fi


    copy_bmp_files_to_boot ${BOARD_NAME}

    cp -a ${out_dir}/root ${RESULT_DIR}
    cp ${TOP}/device/nexell/${BOARD_NAME}/init.rc ${RESULT_DIR}/root
#cp ${TOP}/device/nexell/${BOARD_NAME}/updater-recovery-script ${RESULT_DIR}/root     # SDY -- added

    ${TOP}/device/nexell/tools/mkinitramfs.sh ${RESULT_DIR}/root ${RESULT_DIR}
    cp ${RESULT_DIR}/root.img.gz ${RESULT_DIR}/boot
    cp ${RESULT_DIR}/root.img.gz ${TOP}/out/target/product/${BOARD_NAME}/ramdisk.img

    if [ -f ${out_dir}/ramdisk-recovery.img ]; then
        cp ${out_dir}/ramdisk-recovery.img ${RESULT_DIR}/boot
    fi

	make_ext4 ${BOARD_NAME} boot
    vmsg "end make_boot"
}

function make_system()
{
    vmsg "start make_system"
    local out_dir="${TOP}/out/target/product/${BOARD_NAME}"
    cp -a ${out_dir}/system ${RESULT_DIR}

    #apply_android_overlay
    remove_android_banned_files

    #cp ${out_dir}/system.img ${RESULT_DIR}
    make_ext4 ${BOARD_NAME} system
		
    vmsg "end make_system"
}

function make_cache()
{
    vmsg "start make_cache"
    local out_dir="${TOP}/out/target/product/${BOARD_NAME}"
    cp -a ${out_dir}/cache ${RESULT_DIR}
	cp ${out_dir}/cache.img ${RESULT_DIR}

    vmsg "end make_cache"
}

function make_userdata()
{
    vmsg "start make_userdata"
    local out_dir="${TOP}/out/target/product/${BOARD_NAME}"
    cp -a ${out_dir}/data ${RESULT_DIR}/userdata
	cp ${out_dir}/userdata.img ${RESULT_DIR}

    vmsg "end make_userdata"
}

function make_misc()
{
    vmsg "start make_misc"

    mkdir -p ${RESULT_DIR}/misc

    make_ext4 ${BOARD_NAME} misc

    vmsg "end make_misc"
}

function make_recovery()
{
    vmsg "start make_recovery"
    local out_dir="${TOP}/out/target/product/${BOARD_NAME}"

    mkdir -p ${RESULT_DIR}/recovery

    cp ${TOP}/kernel/arch/arm/boot/Image ${RESULT_DIR}/recovery
    cp ${TOP}/kernel/arch/arm/boot/uImage ${RESULT_DIR}/recovery
    cp ${out_dir}/ramdisk-recovery.img ${RESULT_DIR}/recovery
    cp ${TOP}/device/nexell/s5p6818_navi/boot/logo.bmp ${RESULT_DIR}/recovery
    cp ${TOP}/device/nexell/s5p6818_navi/boot/battery.bmp ${RESULT_DIR}/recovery
    cp ${TOP}/device/nexell/s5p6818_navi/boot/update.bmp ${RESULT_DIR}/recovery
#cp ${RESULT_DIR}/root.img.gz ${RESULT_DIR}/recovery

# SDY -- TEST
#cp ${TOP}/device/nexell/s5p6818_navi/init.rc ${RESULT_DIR}/recovery
#cp ${TOP}/device/nexell/s5p6818_navi/svn-commit.tmp ${RESULT_DIR}/recovery

    make_ext4 ${BOARD_NAME} recovery

    vmsg "end make_recovery"
}

source device/nexell/tools/common.sh

parse_args $@
print_args
export VERBOSE
export ANDROID_VERSION_MAJOR=$(get_android_version_major)
export BOOTARGS="console=ttySAC3,115200n8 androidboot.hardware=s5p6818_navi androidboot.console=ttySAC3 initrd=0x49000000,0x200000 init=/init lpj=1388544"
export TARGET_DEBUG_TRACE=${DEBUG_TRACE}
export TARGET_BUILD_BUSYBOX=${BUILD_BUSYBOX}

set_android_toolchain_and_check
CHIP_NAME=$(get_cpu_variant2 ${BOARD_NAME})
#BOARD_PURE_NAME=${BOARD_NAME%_*}
BOARD_PURE_NAME=${BOARD_NAME#*_}
check_board_name ${BOARD_NAME}
check_wifi_device ${WIFI_DEVICE_NAME}
clean_up
build_uboot
build_nxupdate
build_kernel
build_module
build_android
build_dist
