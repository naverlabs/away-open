#!/bin/sh
FIRMWARE_DIR=/system/etc/firmware
avrdude -c linuxgpio -p t88 -U flash:w:${FIRMWARE_DIR}/navi_ctl.hex

