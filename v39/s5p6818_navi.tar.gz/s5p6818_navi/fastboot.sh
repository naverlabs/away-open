#!/bin/sh
fastboot flash partmap device/nexell/s5p6818_navi/partmap.txt
fastboot flash 2ndboot result/2ndboot.bin
fastboot flash bootloader1 result/u-boot.bin
fastboot flash bootloader2 result/u-boot.bin
fastboot flash boot result/boot.img
fastboot flash system result/system.img
fastboot flash cache result/cache.img
fastboot flash userdata result/userdata.img
fastboot flash misc result/misc.img
fastboot flash recovery result/recovery.img
fastboot reboot
