#!/system/bin/sh

#kmsg_log_dir="/data/data/kmsg"
#cat_log_dir="/data/data/logcat"
#log_check_file="/data/data/log_save.txt"

log_dir="/sdcard/log"
kmsg_log_dir="/sdcard/log/kmsg"
cat_log_dir="/sdcard/log/logcat"
log_check_file="/sdcard/log/log_save.txt"

date_now=$(date +"%Y%m%d"_"%H%M%S")

if [ ! -d $log_dir ]; then
    mkdir $log_dir
fi

if [ -s $log_check_file  ]; then
    if [ $(cat $log_check_file) = "1" ]; then
        if [ ! -d $kmsg_log_dir ]; then
            mkdir $kmsg_log_dir
        fi

        if [ ! -d $cat_log_dir ]; then
            mkdir $cat_log_dir
        fi

        echo "" > $kmsg_log_dir/kmsg_$date_now.txt
        cat /proc/kmsg >> $kmsg_log_dir/kmsg_$date_now.txt &
        logcat *:v > $cat_log_dir/logcat_$date_now.txt &
    fi
fi
