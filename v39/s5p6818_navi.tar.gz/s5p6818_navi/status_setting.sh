#!/system/bin/sh

status_dir="/misc/status"
calibration_file="/misc/.sc_cal"
usim_cnt_file="/misc/simcnt.txt"
pwr_cnt_file="/misc/pwrcnt.txt"
reboot_save="/misc/log/reboot_save.txt"
log_dir="/misc/log"

if [ ! -d $log_dir ]; 
	then
		mkdir $log_dir
		chown system.system $log_dir
		chmod 770 $log_dir
fi

if [ ! -s $reboot_save ]; 
	then
		echo "0" > $reboot_save
		chown system.system $reboot_save
		chmod 770 $reboot_save
fi

if [ ! -e $calibration_file ]; 
	then
		echo "0 0 0 0" > $calibration_file
		chown system.system $calibration_file
		chmod 770 $calibration_file
fi

if [ ! -e $usim_cnt_file ]; then
    echo "0" > $usim_cnt_file
    chown system.system $usim_cnt_file
    chmod 660 $usim_cnt_file
fi

if [ ! -e $pwr_cnt_file ]; then
    echo "0" > $pwr_cnt_file
    chown system.system $pwr_cnt_file
    chmod 660 $pwr_cnt_file
fi

if [ ! -d $status_dir ]; then
    mkdir $status_dir
    chown system.system $status_dir
    chmod 770 $status_dir

    for i in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30
    do
        echo 3 > $status_dir/test_result_quality_$i.txt
        echo 3 > $status_dir/test_result_production_$i.txt

        chown system.system $status_dir/test_result_quality_$i.txt
        chown system.system $status_dir/test_result_production_$i.txt

        chmod 770 $status_dir/test_result_quality_$i.txt
        chmod 770 $status_dir/test_result_production_$i.txt
    done
fi

