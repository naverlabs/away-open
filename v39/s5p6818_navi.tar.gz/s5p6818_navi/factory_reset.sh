#!/system/bin/sh

rm -rf /cache/*
rm -rf /data/*
sync
