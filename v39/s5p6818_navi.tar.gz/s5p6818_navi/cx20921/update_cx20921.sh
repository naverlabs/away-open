#!/bin/sh
FIRMWARE_DIR=/system/etc/firmware
cxdish -r 44 -D /dev/i2c-1 flash ${FIRMWARE_DIR}/image.sfs ${FIRMWARE_DIR}/iflash.bin
